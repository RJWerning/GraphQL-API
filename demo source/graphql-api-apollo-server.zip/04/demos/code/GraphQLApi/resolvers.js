const Query = require('./resolvers/query');
const Session = require('./resolvers/session');
module.exports = {
  Query,
  Session,
};
